import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./Components/Navbar";

import Home from "./Pages/Home";
import RolesList from "./Pages/Admin/RolesList";
import AddRoles from "./Pages/Admin/AddRoles";
import UpdateRoles from "./Pages/Admin/UpdateRoles";
import UsersList from "./Pages/Admin/UsersList";
import AddUsers from "./Pages/Admin/AddUsers";
import Login from "./Pages/Login";

const App = () => {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/userslist" element={<UsersList />} />
        <Route path="/login" element={<Login />} />
        <Route path="/addusers" element={<AddUsers />} />
        <Route path="/roleslist" element={<RolesList />} />
        <Route path="/addroles" element={<AddRoles />} />
        <Route path="/roles/:id" element={<UpdateRoles />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
