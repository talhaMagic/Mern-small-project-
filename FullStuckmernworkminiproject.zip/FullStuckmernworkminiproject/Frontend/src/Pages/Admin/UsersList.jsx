import React, { useEffect, useState } from "react";

const UsersList = () => {
  const [AllUsers, setAllUsers] = useState([]);

  // Fetch all users
  const fetchUsers = async () => {
    const response = await fetch("http://localhost:5000/Userget");
    const data = await response.json();
    setAllUsers(data);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Delete a user

  const deleteUser = async (id) => {
    try {
      const response = await fetch(`http://localhost:5000/Userget/${id}`, {
        method: "DELETE",
      });
      if (response.ok) {
        // Remove user from the local state after successful deletion
        setAllUsers(AllUsers.filter(user => user._id !== id));
        alert("User deleted successfully");
      } else {
        alert("Failed to delete user");
      }
    } catch (error) {
      console.log(error);
      alert("An error occurred while deleting the user");
    }
  };

  return (
    <div>
      <h1 className="mt-4 text-center">User List</h1>
      <div className="container mt-5">
        <table className="table">
          <thead>
            <tr>
              <th scope="col">Avatar</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Role</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {AllUsers.map((user, index) => (
              <tr key={user._id}>
                <td>
                  <img
                    src={user.UserAvatar}
                    alt="User Avatar"
                    style={{
                      width: "50px",
                      height: "50px",
                      borderRadius: "50%",
                    }}
                  />
                </td>
                <td>{user.UserName}</td>
                <td>{user.UserEmail}</td>
                <td>{user.UserRoles.RoleName}</td>
                <td>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => deleteUser(user._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UsersList;
