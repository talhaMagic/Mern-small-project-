import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const AddRoles = () => {
  const [RoleName, setRoleName] = useState("");
  const [RoleStatus, setRoleStatus] = useState(""); // Fixed naming

  const navigate = useNavigate();

  const roleSubmition = async (e) => {
    e.preventDefault();

    try {
      const AddRole = {
        Rolename: RoleName, // Match the backend naming
        rolestatus: RoleStatus, // Match the backend naming
      };

      const response = await fetch("http://localhost:5000/Rolepost", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(AddRole),
      });

      if (response.ok) {
        alert("Role added");
        navigate("/roleslist");
      } else {
        const errorData = await response.json();
        alert(`Role added unsuccessfully: ${errorData.error}`);
      }
    } catch (er) {
      alert(er.message);
    }
  };

  return (
    <div className="container mt-3">
      <h1 className="text-center">Add Roles</h1>
      <form method="POST" onSubmit={roleSubmition}>
        <div className="mb-3">
          <label className="form-label">Role Name</label>
          <input
            type="text"
            className="form-control"
            onChange={(e) => setRoleName(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Role Status</label>
          <select
            className="form-control"
            onChange={(e) => setRoleStatus(e.target.value)} // Fixed naming
            value={RoleStatus} // Fixed naming
          >
            <option value="" disabled>
              Choose Status
            </option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>

        <button type="submit" className="btn btn-primary mt-4">
          Add Role
        </button>
      </form>
    </div>
  );
};

export default AddRoles;
