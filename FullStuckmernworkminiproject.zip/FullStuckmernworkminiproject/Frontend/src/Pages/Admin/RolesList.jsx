import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const RolesList = () => {
  const [AllRole, setAllRole] = useState([]);

  const fetchRoles = async () => {
    const response = await fetch("http://localhost:5000/Roleget");
    setAllRole(await response.json());
  };

  useEffect(() => {
    fetchRoles();
  }, []);

  const deleteRole = async (id) => {
    try {
      await fetch(`http://localhost:5000/Roleget/${id}`, {
        method: "DELETE",
      });
      window.location.reload();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <h1 className="mt-4 text-center">Role List</h1>
      <div className="container mt-5">
        <table className="table">
          <thead>
            <tr>
              <th scope="col">Name</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {AllRole.map((role, index) => {
              return (
                <tr key={index}>
                  <td>{role._id}</td>
                  <td>{role.RoleName}</td>
                  <td>{role.RoleStatus}</td>
                  <td>
                    <Link
                      className="btn btn-success btn-sm me-2"
                      to={`/roles/${role._id}`}
                    >
                      Update
                    </Link>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => deleteRole(role._id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RolesList;
