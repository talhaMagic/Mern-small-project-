import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const UpdateRoles = () => {
  const { id } = useParams();
  const [RoleName, setRoleName] = useState("");
  const [RoleStatus, setRoleStatus] = useState("");

  const navigate = useNavigate();

  const roleUpdation = async (e) => {
    e.preventDefault();

    try {
      const UpdateRole = {
        Rolename: RoleName, // Match the backend naming
        rolestatus: RoleStatus, // Match the backend naming
      };

      const response = await fetch(`http://localhost:5000/Roleget/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(UpdateRole),
      });
      if (response.ok) {
        alert("Role updated");
        navigate("/roleslist");
      } else {
        const errorData = await response.json();
        alert(`Role updated unsuccessfully: ${errorData.error}`);
      }
    } catch (er) {
      alert(er.message);
    }
  };

  return (
    <div className="container mt-3">
      <h1 className="text-center">Add Roles</h1>
      <form onSubmit={roleUpdation}>
        <div className="mb-3">
          <label className="form-label">Role Name</label>
          <input
            type="text"
            className="form-control"
            onChange={(e) => setRoleName(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Role Status</label>
          <select
            className="form-control"
            onChange={(e) => setRoleStatus(e.target.value)}
            value={RoleStatus}
          >
            <option value="" disabled>
              Choose Status
            </option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>

        <button type="submit" className="btn btn-primary mt-4 ">
          Update Role
        </button>
      </form>
    </div>
  );
};

export default UpdateRoles;
