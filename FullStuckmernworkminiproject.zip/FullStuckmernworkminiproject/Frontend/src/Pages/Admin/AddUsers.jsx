import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const AddUsers = () => {
  const [UserName, setUserName] = useState("");
  const [UserEmail, setUserEmail] = useState("");
  const [UserPass, setUserPass] = useState("");
  const [UserRole, setUserRole] = useState("");
  const [UserImage, setUserImage] = useState(null);

  const [AllRole, setAllRole] = useState([]);

  // Fetch roles for the dropdown
  const fetchRoles = async () => {
    const response = await fetch("http://localhost:5000/Roleget");
    setAllRole(await response.json());
  };

  useEffect(() => {
    fetchRoles();
  }, []);

  const navigate = useNavigate();

  const userSubmition = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append("userimage", UserImage);
      formData.append("username", UserName.trim());
      formData.append("useremail", UserEmail.trim());
      formData.append("userpassword", UserPass.trim());
      formData.append("userroleid", UserRole);

      const response = await fetch("http://localhost:5000/Userpost", {
        method: "POST",
        body: formData, // No need to manually set Content-Type
      });

      if (response.ok) {
        alert("User added");
        navigate("/userslist");
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.error}`);
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to add user");
    }
  };

  return (
    <div className="container mt-3">
      <h1 className="text-center">Add Users</h1>
      <form encType="multipart/form-data" onSubmit={userSubmition}>
        <div className="mb-3">
          <label className="form-label">Image</label>
          <input
            type="file"
            className="form-control"
            onChange={(e) => setUserImage(e.target.files[0])}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input
            type="text"
            className="form-control"
            onChange={(e) => setUserName(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            type="email"
            className="form-control"
            onChange={(e) => setUserEmail(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            type="password"
            className="form-control"
            onChange={(e) => setUserPass(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Role</label>
          <select
            className="form-control"
            onChange={(e) => setUserRole(e.target.value)}
          >
            <option value="">Choose Role</option>
            {AllRole.map((role, index) => {
              return (
                <option key={role._id} value={role._id}>
                  {role.RoleName}
                </option>
              );
            })}
          </select>
        </div>

        <button type="submit" className="btn btn-primary mt-4 ">
          Add User
        </button>
      </form>
    </div>
  );
};

export default AddUsers;
