import React, { useState } from "react";
import axios from "axios";
import { jwtDecode } from "jwt-decode";

import { useNavigate } from "react-router-dom";


const Login = () => {

    const navigate = useNavigate();
  const [formData, setFormData] = useState({
    useremail: "",
    userpassword: "",
  });
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(
        "http://localhost:2000/users/login",
        formData
      );

      if (response.status === 200) {
        // Login successful
        setSuccessMessage("Login successful!");
        setErrorMessage("");
        // console.log("Token:", response.data.data); // Token ko store karne ka logic yahan likhein


        const decoded = jwtDecode(response.data.data);
    
      if(decoded.userrole=="customer"){
        navigate('/customer')
    }else if(decoded.userrole == "admin"){
        
        navigate('/admin')
      }

      }
    } catch (error) {
      // Handle errors
      if (error.response && error.response.data) {
        setErrorMessage(error.response.data.message || "Login failed.");
      } else {
        setErrorMessage("An error occurred. Please try again.");
      }
      setSuccessMessage("");
    }
  };

  return (
    <div className="container">
      <h2>Login</h2>
      {successMessage && <p className="success">{successMessage}</p>}
      {errorMessage && <p className="error">{errorMessage}</p>}
      <form onSubmit={handleSubmit} className="login-form">
        <div className="form-group">
          <label htmlFor="useremail">Email:</label>
          <input
            type="email"
            id="useremail"
            name="useremail"
            className="form-control"
            value={formData.useremail}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="userpassword">Password:</label>
          <input
            type="password"
            id="userpassword"
            name="userpassword"
            className="form-control"
            value={formData.userpassword}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className="btn btn-primary">
          Login
        </button>
      </form>
    </div>
  );
};

export default Login;
