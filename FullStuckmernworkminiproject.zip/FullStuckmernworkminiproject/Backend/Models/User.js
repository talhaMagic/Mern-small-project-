

const mongoose = require("mongoose");

const user_module = mongoose.Schema({


    UserAvatar: {
        type: String,
        required: [true, "User Avatar is required"]
    },

    UserName: {
        type: String,
        required: [true, "User name is required"]
    },

    UserEmail: {
        type: String,
        required: [true, "User Email is required"],
        unique: true,
    },

    UserPassword: {
        type: String,
        required: [true, "User password is required"]
    },

    UserRoles: {
        type: mongoose.Schema.ObjectId,
        ref: "Roles",
        required: [true, "User Roles is required"],
    },



});
const UserCollection = mongoose.model("User", user_module);

module.exports = { UserCollection };