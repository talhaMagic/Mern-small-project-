
const bcrypt = require("bcrypt");
const { UserCollection } = require("../Models/User");


// image packages
const multer = require("multer");
const cloud = require("cloudinary").v2;
const { CloudinaryStorage } = require("multer-storage-cloudinary");



//GET METHOD
// API http://localhost:5000/Userget
async function UserRegisterpage(req, res) {
    try {
      // Populate the correct path 'UserRoles' with 'RoleName'
      const getAllUser = await UserCollection.find().populate("UserRoles", "RoleName");
      return res.status(200).send(getAllUser);
    } catch (error) {
      console.error(error);
      return res.status(500).send({ error: "An error occurred while fetching users" });
    }
  }
  


// @METHOD POST
// API http://localhost:5000/Userpost

async function UserRegistercreate(req, res) {
    try {
      const {username, useremail, userpassword, userroleid } = req.body;
  
      if (!req.file) {
        return res.status(400).send({ error: "User Avatar is required" });
      }
  
      if (!username || username.length < 4 || !/^[A-Za-z]{4,}$/.test(username)) {
        return res.status(400).send({ error: "Invalid username" });
      }
      if (!useremail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(useremail)) {
        return res.status(400).send({ error: "Invalid email" });
      }
      if (!userpassword) {
        return res.status(400).send({ error: "User Password is required" });
      }
      if (!userroleid) {
        return res.status(400).send({ error: "User Role is required" });
      }
  
      const encPassword = await bcrypt.hash(userpassword, 10);
  
      if (!userroleid) {
        return res.status(400).send({ error: "User Role is required" });
      }
  
      const findIfExists = await UserCollection.find({
        UserEmail: useremail.toLowerCase(),
      });
  
      if (findIfExists.length > 0) {
        return res.status(409).send({ error: "Useremail already exists" });
      }
  
      await UserCollection.create({
        UserName: username,
        UserEmail: useremail.toLowerCase(),
        UserPassword: encPassword,
        UserRoles: userroleid,
        UserAvatar: req.file.path,
      });
  
      return res.status(201).send(req.body);
    } catch (error) {
      console.log(error);
    }
  }

//METHOD MIDDLEWARE IMAGE UPLOAD
//API 
function middlewareUpload() {
    cloud.config({
      cloud_name: process.env.CLOUD_NAME,
      api_key: process.env.CLOUDINARY_API_KEY,
      api_secret: process.env.CLOUDINARY_SECRET_API_KEY,
    });
  
    const multerStorage = new CloudinaryStorage({
      cloudinary: cloud,
      params: {
        folder: "userimgs",
        allowed_formats: ["png", "jpg"],
      },
    });
  
    const superves = multer({ storage: multerStorage });
    return superves;
  }
  
// METHOD -- DELETE
// API    -- http://localhost:5000/Userget/:id

async function deleteUser(req, res) {
    const urlUser_id = req.params.id;
  
    await UserCollection.deleteOne({_id: urlUser_id,});
  
    return res.status(200).send({ message: "user deleted successfully" });
  }
  

module.exports = { UserRegisterpage, UserRegistercreate, middlewareUpload,deleteUser}