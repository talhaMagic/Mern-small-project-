

const { RolesCollection } = require("../Models/Roles");


//GET METHOD
//API http://localhost:5000/Roleget

async function Rolesget(req, res) {
    const Allroles = await RolesCollection.find();
    return res.status(200).send(Allroles);

}

//POST METHOD
//API http://localhost:5000/Rolepost

async function Rolescreate(req, res) {

    const { Rolename, rolestatus } = req.body;

    if (!Rolename) { return res.status(200).send("Role name is required") }

    const roleNamechekar = /^[A-Za-z]+$/;

    if (!roleNamechekar.test(Rolename)) { return res.status(400).send({ error: "Role only aplhabets" }); }

    if (!rolestatus) { return res.status(400).send({ error: "Role status is requierd" }); }

    const exsit = await RolesCollection.find({

        RoleName: Rolename.toLowerCase(),
    });

    if (exsit.length > 0) { return res.status(409).send({ error: "role name already exists" }); }

    await RolesCollection.create({

        RoleName: Rolename.toLowerCase(),
        RoleStatus: rolestatus,

    });

    return res.status(200).send("Roles create page");

}

//DELETE METHOD
//API http://localhost:5000/Roleget/6746cd1e51cc27c2fde9b2a0

async function deleterole(req, res) {

    const roleid = req.params.id;
    await RolesCollection.deleteOne({
        _id: roleid,
    });

    return res.status(200).send({ message: "Role delete sucess" });

}

//Update METHOD
//API http://localhost:5000/Roleget/674857f41e42469529bf2314
async function updaterole(req, res) {
    const roleid = req.params.id;
  
    try {
      const getallrolename = await RolesCollection.findOne({ _id: roleid });
  
      if (!getallrolename) {
        return res.status(404).send({ error: "Role not found" });
      }
  
      const { Rolename, rolestatus } = req.body;
  
      if (!Rolename) {
        return res.status(400).send({ error: "Role name is required" });
      }
  
      const roleNamechekar = /^[A-Za-z]+$/;
      if (!roleNamechekar.test(Rolename)) {
        return res.status(400).send({ error: "Role name must contain only alphabets" });
      }
  
      if (!rolestatus) {
        return res.status(400).send({ error: "Role status is required" });
      }
  
      await RolesCollection.updateOne(
        { _id: roleid },
        {
          $set: {
            RoleName: Rolename.toLowerCase(),
            RoleStatus: rolestatus,
          },
        }
      );
  
      return res.status(200).send({ message: "Role updated successfully", data: req.body });
    } catch (error) {
      console.error("Error updating role:", error);
      return res.status(500).send({ error: "Internal server error" });
    }
  }
  





module.exports = { Rolesget, Rolescreate, deleterole,updaterole}
