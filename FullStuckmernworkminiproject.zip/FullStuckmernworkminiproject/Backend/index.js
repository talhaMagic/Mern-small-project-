
const express = require("express");

const app = express();

const dotenv = require("dotenv").config();

app.use(express.urlencoded({ extended: true }));

app.use(express.json());

//CORS CONNECT BACKEND TO FRONTEND

const cors = require("cors");

const corsOptions = {
    origin: "http://localhost:3000",
    methods: "GET, POST, PUT, DELETE",
    allowedHeaders: "Content-Type, Authorization",
  };

  app.use(cors(corsOptions)); // Use cors as middleware


//DB CONNECT MONGO DB

const { DBconnect } = require("./Config/db");

//-----------------------END DB CONNECT---------------------------//
//---------------------------------------------------------------//

//IMPORT MIDDLEWHERE IMGUPLAOD

// const Imguplaod = middlewareUpload();

//---------------------END MIDDLEWHERE IMGUPLAOD------------------//
//---------------------------------------------------------------//


//IMPORT USERCONTROLLERS 

const { UserRegisterpage, UserRegistercreate,middlewareUpload,deleteUser} = require("./Controllers/Usercontroller");

  // image imports
  const uplImgFunc = middlewareUpload();

app.route("/Userget").get(UserRegisterpage);

app.route("/Userpost").post(uplImgFunc.single("userimage"),UserRegistercreate);

app.route("/Userget/:id").delete(deleteUser);

//----------------------END USERCONTROLLERS----------------------//
//---------------------------------------------------------------//

//IMPORT ROLESCONTROLLERS

const { Rolesget,Rolescreate,deleterole,updaterole} = require("./Controllers/Rolecontrollers");

app.route("/Roleget").get(Rolesget);

app.route("/Rolepost").post(Rolescreate);

app.route("/Roleget/:id").delete(deleterole);

app.route("/Roleget/:id").put(updaterole);

app.listen(process.env.PORT, function () {

    console.log(`SERVER IS CONNECT PORT${process.env.PORT}`);
    DBconnect();

})
